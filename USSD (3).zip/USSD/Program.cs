﻿// See https://aka.ms/new-console-template for more information
using USSD;

//Console.WriteLine("Hello, World!");


Login  Login = new Login();


Login.Reg();
Login.Log();


